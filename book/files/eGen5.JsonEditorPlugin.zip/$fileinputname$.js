

propertiesApp.controller('$fileinputname$Editor', ['$scope', function ($scope) {
  
    $scope.sortableOptions = {
        start: function (e, ui) {
            
            $(ui.item).width($(ui.item).parent().width())

        },
        axis: 'y'
    };

    $scope.init = function (datakey, objectFormat) {

         
        var elementkey = "#txt" + datakey;
        $scope.ObjectFormat = objectFormat;//{ Id: 0, Name: '', code: '', image: '', link: '', text: '' };
        if ($(elementkey).val() != "") {
            $scope.Data = JSON.parse($(elementkey).val());
            //convertDateStringsToDates($scope.Data);
        }
        else {
            $scope.Data = [];

        }
        $scope.$watch("Data", function (newval) {

           

            $(elementkey).val(JSON.stringify(newval));
            $(elementkey).trigger("blur");

        }, true);

    }
   
    $scope.getMaxId = function () {
        var max = 0;
        for(var i=0;i< $scope.Data.length;i++)
        {
            if (max < $scope.Data[i].Id)
                max = $scope.Data[i].Id;

        }

        max++;
        return max;

    }
  
    $scope.CurrentObject = null;
    $scope.Clear = function () {
        if(confirm("are you sure?"))
            $scope.Data = [];

    }
    $scope.EditingMode = null;
    $scope.AddNew = function () {
        $scope.CurrentObject = angular.fromJson(angular.toJson($scope.ObjectFormat));
        $scope.CurrentObject.Id = $scope.getMaxId();      
        $scope.EditingMode = "new";
            
    }
    
    
    $scope.RemoveItem = function (item) 
    {
        if(confirm("are you sure?"))
            for (var i = 0; i < $scope.Data.length; i++)
                if ($scope.Data[i] == item)
                    $scope.Data.splice(i, 1);
    }

    $scope.EditItem = function (item) {
        $scope.CurrentObject = item;
        $scope.EditingMode = "edit";

    }

    $scope.UpdateItem = function () {
        if(  $scope.EditingMode == "new")
            $scope.Data.push($scope.CurrentObject);

    }
    

    $scope.SelectImage = function (field) {

       
        top.IDE.resultExtendedCallBack = function (fullImageArray) {
           
            $scope.CurrentObject[field] = fullImageArray;
            top.IDE.resultExtendedCallBack = undefined;

        }
      

        top.IDE.SelectImage(document.getElementById("ImageField"));
    }
    

}]);



 