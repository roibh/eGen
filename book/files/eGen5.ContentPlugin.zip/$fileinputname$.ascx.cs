﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls; 
using eGen.UI.Pages;
using eGen.Objects;
using eGen.Cache;
using eGen.UI.Controls;


  
public partial class $rootnamespace$_$safeitemname$ : BasePageControl
{
    

    protected void Page_Load(object sender, EventArgs e)
    {
         //use Properties[PropertyKey]  to access Control's properties
    }


    
}